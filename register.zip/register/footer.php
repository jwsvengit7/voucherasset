
    <footer id="page-footer" class="mTopDiv">
        <div class="container">
            
    
            <div class="custom_footer__section">
                <ul class="c_footer__wrap f__item">
                    <li>
                        <div class="footer_content__wrapper">
                                <img src="logo.png" title="Footer_Logo" width="80" height="80" alt="Ignite" class="ro">
                             <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour.</p>
                            <ul>
                                    <li><i class="cb-f__mail-icon f__icon" aria-hidden="true"></i><a href="mailto:cmsbrand93@gmail.com">info@voucherasset.com</a></li>
                                    <li><i class="cb-f__phone-icon f__icon" aria-hidden="true"></i>+00 123-456-789</li>
                                    <li><i class="cb-f__navigator-icon f__icon" aria-hidden="true"></i>123 6th St.Melbourne, FL 32904</li>
                            </ul>
                        </div>
                    </li>
                </ul>
                <ul class="footer_section__wrap_1 f__item">
                        <h4>Navigate</h4>
                        <li><a href="#">Courses</a></li>
                        <li><a href="#">Schedule</a></li>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Our Blog</a></li>
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="#">Services</a></li>
                </ul>
                <ul class="footer_section__wrap_2 f__item">
                        <h4>Popular Courses</h4>
                        <li><a href="#">Business Strategy</a></li>
                        <li><a href="#">Business English</a></li>
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="#">Features</a></li>
                </ul>
                <ul class="footer_section__wrap_3 f__item">
                        <h4>Support</h4>
                        <li><a href="#">Documentation</a></li>
                        <li><a href="#">Forums</a></li>
                        <li><a href="#">Social Media</a></li>
                    
                </ul>
            </div>
                    
            <div class="tool_dataprivacy"><a href="../dataprivacy/summary.php">Data retention summary</a></div>
         
<script src="../lib/javascript.php/1662375728/lib/requirejs/require.min.js"></script>



        </div>
    </footer>
    <div class="footer_signature__wrap">
        <div class="container">
            <div class="col-md-12">
                <div class="footer_signature__content">
                        <p>&copy; Copyright 2022| Ignite Theme by CmsBrand | All Rights Reserved | Powered by Moodle</p>
                </div>
            </div>
        </div>
    </div>
    <!--@@Strip Section //Start-->
        <div class="side_strip__section">
               
        </div>
    <!--@@Strip Section //End-->
    <!-- Start Back To Top -->
        <div id="back_to__top" style="display: none;"> 
         <a class="scrollup" href="javascript:void(0);" title="Go to top">
            <em>Top</em>
         </a>
        </div>